var cex = {};



var UNIQUE_MAP_VIEWER_ID = 'cex_iframe';
var latitude = -1;
var longitude = -1;

/**
 * Here is where you want to render a latitude and longitude. We create an iframe so we
 * we can inject it. We just want to maintain a single instance of it though.
 */
function showMap() {
	var mapViewerDOM = document.getElementById(UNIQUE_MAP_VIEWER_ID);
	if (mapViewerDOM) {
		$(mapViewerDOM).removeClass('hidden');
		chrome.runtime.sendMessage({
			target: 'map_viewer',
			method: 'runFunction',
			methodName: "focusSearchBar"
		});
	} else {

		mapViewerDOM = document.createElement('iframe');
		mapViewerDOM.setAttribute('id', UNIQUE_MAP_VIEWER_ID);
		mapViewerDOM.setAttribute('src', chrome.extension.getURL('map_viewer.html'));
		mapViewerDOM.setAttribute('frameBorder', '0');
		mapViewerDOM.setAttribute('width', '99.90%');
		mapViewerDOM.setAttribute('height', '100%');
		mapViewerDOM.setAttribute('style', 'position: fixed; top: 0; left: 0; overflow: hidden; z-index: 99999');
		mapViewerDOM.onload = function (e) {


			chrome.runtime.sendMessage({
				target: 'map_viewer',
				method: 'runFunction',
				methodName: "renderMap",
				data: {
					latitude: latitude,
					longitude: longitude
				}
			});
			chrome.runtime.sendMessage({
				target: 'map_viewer',
				method: 'runFunction',
				methodName: "focusSearchBar"
			});
		}
		document.body.appendChild(mapViewerDOM);

	}
	// Send message to iframe to focus on search bar
}

chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		if (request.target == 'content' && request.method == "runFunction") {
			cex[request.methodName](request.data)
		}
	});

cex.closeIframe = function(){
	var mapViewerDOM = document.getElementById(UNIQUE_MAP_VIEWER_ID);
	if (mapViewerDOM) $(mapViewerDOM).addClass('hidden')
};

cex.insertObjectCard = function(objectData){
	newDiv = '&nbsp;<a href="https://www.google.com/search?q=' + objectData.searchName+ '" ' +
		'style="display: inline-block; border-radius: 5px; width: 260px; ' +
		'cursor: pointer; border: 1px solid #eee; overflow: hidden;text-decoration:none;">' +
		'<table style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding-top:0px;padding-bottom:0px;padding-right:0px;padding-left:0px;width:100%;display:block">' +
		'<tbody>' +
		'<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left">' +
		'<td style="word-break:break-word;border-collapse:collapse!important;vertical-align:top;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;text-align:left;padding:0;">' +
		'<img src="' +  objectData.photo + '" style="background: #eee; display: inline-block; max-width: 100px;vertical-align: top;">' +
		'</td><td style="word-break:break-word;border-collapse:collapse!important;vertical-align:top;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;text-align:left;padding:10px; color: #777">' +
		'<span><b style="color: #333">' +  objectData.name + '</b>&nbsp;' +
		'</span></td>' +
		'</tr></tbody></table></a>&nbsp;';
	cex.textTarget.innerHTML = cex.beforeText + newDiv + cex.afterText;
	cex.closeIframe();
};



function myscript(evt){
	// look for an @ symbol
	if (evt.keyCode == 64) {
		if (cex.checkNextAtSymbol){
			cex.checkNextAtSymbol = false;
			var currentText = evt.target.innerHTML,
				prevText = cex.htmlAtLastCheck,
				breakIndex = 0,
				beforeText = null,
				afterText = null;
			for (var i = 0; i < currentText.length; i++) {
				if (currentText[i] != prevText[i] && currentText[i] == "@"){
					breakIndex = i;
					beforeText = currentText.slice(0,i);
					afterText = currentText.slice(i+1,currentText.length);
					cex.beforeText = beforeText;
					cex.afterText = afterText;
					cex.textTarget = evt.target;
					break;
				}
			}
			evt.target.innerHTML = beforeText + afterText;
			evt.preventDefault();
			evt.stopImmediatePropagation();
			showMap();
		} else {
			cex.checkNextAtSymbol = true;
			cex.htmlAtLastCheck = evt.target.innerHTML;
		}
	} else {
		cex.checkNextAtSymbol = false;
		cex.htmlAtLastCheck = null;
	}
};



function addListenerToCompose(){
	var composeArea =  $('.editable[aria-label="Message Body"]');
	composeArea.on('keypress', myscript)
}

function checkCompose(){
	var composeArea = $('.editable[aria-label="Message Body"]');
	if (composeArea  && (composeArea.length > 0 )&& !cex.isComposing){
		cex.isComposing = true;
		addListenerToCompose();
	}
	if ((!composeArea || composeArea.length == 0)&& cex.isComposing){
		cex.isComposing = false;
	}
}


function startTimer(){
	cex.isComposing = false;
	cex.checkComposeInterval = window.setInterval(checkCompose, 200);
}



function startup(){
	startTimer();
}

if(window.attachEvent) {
	window.attachEvent('onload', yourFunctionName);
} else {
	if(window.onload) {
		var curronload = window.onload;
		var newonload = function(evt) {
			curronload(evt);
			startup();
		};
		window.onload = newonload;
	} else {
		window.onload = startup;
	}
}